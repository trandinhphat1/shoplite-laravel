class ImportDoc {
    constructor(id, supplier_id, final_amount, discount_amount,shipcost,paid_amount, bank_id,wh_id) {
    this.id = id;
      this.supplier_id = supplier_id;
      this.final_amount = final_amount;
      this.discount_amount = discount_amount;
      this.shipcost = shipcost;
      this.paid_amount = paid_amount;
      this.bank_id = bank_id;
      this.wh_id = wh_id;
     
    }
 
}
 